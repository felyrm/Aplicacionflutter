package com.mycompany.marketlist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
